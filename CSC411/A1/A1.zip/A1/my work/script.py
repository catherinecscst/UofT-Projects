from pylab import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
import random
import time
from scipy.misc import imread
from scipy.misc import imresize
import matplotlib.image as mpimg
import os
from scipy.ndimage import filters
import urllib

act_male = list(set([a.split("\t")[0] for a in open("facescrub_actors.txt").readlines()]))
act_female = list(set([a.split("\t")[0] for a in open("facescrub_actresses.txt").readlines()]))
all_act = act_male + act_female


def timeout(func, args=(), kwargs={}, timeout_duration=1, default=None):
    '''From:
    http://code.activestate.com/recipes/473878-timeout-function-using-threading/'''
    import threading
    class InterruptableThread(threading.Thread):
        def __init__(self):
            threading.Thread.__init__(self)
            self.result = None

        def run(self):
            try:
                self.result = func(*args, **kwargs)
            except:
                self.result = default

    it = InterruptableThread()
    it.start()
    it.join(timeout_duration)
    if it.isAlive():
        return False
    else:
        return it.result

def rgb2gray(rgb):
    '''Return the grayscale version of the RGB image rgb as a 2D numpy array
    whose range is 0..1
    Arguments:
    rgb -- an RGB image, represented as a numpy array of size n x m x 3. The
    range of the values is 0..255
    '''

    r, g, b = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2]
    gray = 0.2989 * r + 0.5870 * g + 0.1140 * b

    return gray/255.

###provided code above

#Note: you need to create the uncropped folder first in order
#for this to work

testfile = urllib.URLopener()

def getting_uncropped():
    for src_path in ["facescrub_actresses.txt", "facescrub_actors.txt"]:
        for a in all_act:
            name = a.split()[1].lower()
            i = 0
            for line in open(src_path):
                if a in line:
                    filename = name+str(i)+'.'+line.split()[4].split('.')[-1]
                    coords = line.split()[-2].split(",")
                    timeout(testfile.retrieve, (line.split()[4], "uncropped/"+filename), {}, 30)
                    #print filename, i

                    if not os.path.isfile("uncropped/"+filename):
                        continue

                    try:
                        readimg = imread(os.path.join("uncropped/", filename))
                        cropped = readimg[int(coords[1]):int(coords[3]),int(coords[0]):int(coords[2])]
                        gray_scale = rgb2gray(cropped)
                        resized = imresize(gray_scale, (32, 32))
                        imsave("cropped/"+filename, resized, cmap = cm.gray)
                    except Exception as e:
                        print filename, ":", str(e)
                        continue
                    i += 1

getting_uncropped()


