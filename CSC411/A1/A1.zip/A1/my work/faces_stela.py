from pylab import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
import random
import time
from scipy.misc import *
import matplotlib.image as mpimg
import os
from scipy.ndimage import filters
import urllib


def get_set(actors, train_size):
    training_sets = {}
    validation_sets = {}
    test_sets = {}

    for actor in actors:
        temp = []
        for image in os.listdir("cropped/"):
            if actor in image:
                temp.append(image)
        np.random.seed(7)
        np.random.shuffle(temp)
        training_sets[actor] = temp[20:20 + train_size]
        validation_sets[actor] = temp[10:20]
        test_sets[actor] = temp[0:10]
    return training_sets, validation_sets, test_sets


def get_set_gender(actors, train_size):
    training_sets = {}
    validation_sets = {}
    test_sets = {}

    for actor in actors:
        a = actor.split()[1].lower()
        temp = []
        for image in os.listdir("cropped/"):
            if a in image:
                temp.append(image)
        np.random.seed(7)
        np.random.shuffle(temp)
        training_sets[actor] = temp[10:10 + train_size]
        validation_sets[actor] = temp[0:10]
        test_sets[actor] = temp[10 + train_size:20 + train_size]
    return training_sets, validation_sets, test_sets


def get_test_gender(actors, train_size):
    test_sets = {}

    for actor in actors:
        a = actor.split()[1].lower()
        temp = []
        for image in os.listdir("cropped/"):
            if a in image:
                temp.append(image)
        np.random.seed(7)
        np.random.shuffle(temp)
        # training_sets[actor] = temp[10:10 + train_size]
        # validation_sets[actor] = temp[0:10]
        test_sets[actor] = temp[0:10]
    return test_sets


def f(x, y, theta):
    x = vstack((ones((1, x.shape[1])), x))
    return sum ((y - dot(theta.T, x)) ** 2)


def df(x, y, theta):
    x = vstack((ones((1, x.shape[1])), x))
    return -2 * sum((y - dot(theta.T, x)) * x, 1)


def grad_descent(f, df, x, y, init_t, alpha, iteration):
    EPS = 1e-5
    prev_t = init_t - 10 * EPS
    t = init_t.copy()
    max_iter = iteration
    iter = 0
    while norm(t - prev_t) > EPS and iter < max_iter:
        prev_t = t.copy()
        t -= alpha*df(x, y, t).reshape(1025, 1)

        if iter % 500 == 0:
            print "Iter", iter
            print "x = (%.2f, %.2f, %.2f), f(x) = %.2f" % (t[0], t[1], t[2], f(x, y, t))
            print "Gradient: ", df(x, y, t), "\n"
        iter += 1
    return t

def grad_descent_7(f, df, x, y, init_t, alpha):
    EPS = 1e-5
    prev_t = init_t - 10 * EPS
    t = init_t.copy()

    max_iter = 10000
    iter = 0
    while norm(t - prev_t) > EPS and iter < max_iter:
        prev_t = t.copy()
        t -= alpha * vectorized_gradient(x, y.T, t)
        if iter % 500 == 0:
            print "Iter: ", iter
        iter += 1
    return t

def grad_descent_2(f, df, x, y, init_t, alpha, iteration):
    EPS = 1e-5
    prev_t = init_t - 10 * EPS
    t = init_t.copy()
    max_iter = iteration
    iter = 0
    while norm(t - prev_t) > EPS and iter < max_iter:
        prev_t = t.copy()
        t -= alpha * vectorized_gradient(x, y.T, t)
        if iter % 500 == 0:
            print "Iter", iter
        iter += 1
    return t


# input set is a set containing training set or valid set, or test set for a
# certain actor
def get_img_vector(input_set):
    l = np.zeros([len(input_set), 1024])

    i = 0
    for f_name in os.listdir("cropped/"):
        if f_name in input_set:

            path = "cropped/" + f_name
            im = imread(path)
            im = im.flatten()
            l[i] = reshape(np.array(im), [1, 1024])
            # print "l[i]", l[i]
            i += 1
    l /= 255
    return l


def vec_set(training, validation, test):
    tr_vec = get_img_vector(training)
    # print "tr_vec: ", tr_vec
    va_vec = get_img_vector(validation)
    te_vec = get_img_vector(test)

    return tr_vec, va_vec, te_vec


def percentage(x, y, theta):
    set_size = x.shape[1]
    hypo = dot(theta.T, vstack((ones((1, x.shape[1])), x)))
    correct = 0.

    for i in range(set_size):
        if hypo[:, i] > 0.5:
            if y[0][i] == 1:
                correct += 1
        else:
            if y[0][i] == 0:
                correct += 1
    percent = correct/set_size
    return percent * 100


def percentage_2(x, y, theta):
    set_size = x.shape[1]
    hypo = dot(vstack((ones((1, x.shape[1])), x)).T, theta)

    correct = 0.
    for i in range(len(y)):
        if y[i].argmax() == hypo[i].argmax():
            correct += 1
    percent = correct / set_size * 100
    return percent


def get_several_y(set_size, act_lst):
    length = len(act_lst) # 6
    total_len = set_size * length #60
    y = np.zeros((total_len, length))
    count = 0
    position = 0
    for i in range(total_len):
        flag = 0
        for j in range(length):
            if j % length == position and flag == 0:
                y[i][j] = 1
                count += 1
                flag = 1
                if count == set_size:
                    position += 1
                    print position
                    count = 0
    return y


def get_y(set_a, set_b):
    print "----------------------"
    result = []
    print len(set_a), len(set_b)
    y = np.zeros((len(set_a) + len(set_b)))
    for i in range(len(set_a), len(set_b) + len(set_a)):
        y[i] = 1

    result.append(y)
    return array(result)


def get_y_gender(sets):
    result = []
    length = len(sets)
    y = np.zeros(length)
    for i in range(length/2, length):
        y[i] = 1

    result.append(y)
    return array(result)


def get_x(set_a, set_b):
    result = np.vstack((set_a, set_b))
    return result


def cost_function(x, y, theta):
    x = np.vstack((np.ones((1, x.shape[1])), x)).T
    return np.sum((y - dot(x, theta.T)) ** 2)


def vectorized_gradient(x, y, theta):
    x = np.vstack((np.ones((1, x.shape[1])), x))
    return 2 * np.dot(x, (dot(theta.T, x) - y).T)


def finite_difference_compare(x, y, theta, i, j):

        h = 1e-6
        theta_h = theta.copy()
        add = theta[i, j] + h
        theta_h[i, j] = add
        x0 = array(x[1].T)
        x = x0[:, np.newaxis]
        y = y[1][np.newaxis, :]
        print "At point: (", i, ",", j, ")"
        finite_diff = (cost_function(x, y, (theta_h).T) - cost_function(x, y, theta.T))/float(h)
        print "finite difference: ", finite_diff
        gradient_output = vectorized_gradient(x, y.T, theta)[i, j]
        print "gradient output: ", gradient_output


# Above is all the helper function
def part3(iteration):
    actors = ["baldwin", "carell"]
    train_set, val_set, test_set = get_set(actors, 70)
    # create set for training set is 2
    train_set_2, val_set_2, test_set_2 = get_set(actors, 2)
    # print train_set["baldwin"]
    # print train_set["carell"]

    baldwin_train, baldwin_val, baldwin_test = vec_set(train_set["baldwin"], val_set["baldwin"], test_set["baldwin"])
    # print baldwin_train
    carell_train, carell_val, carell_test = vec_set(train_set["carell"], val_set["carell"], test_set["carell"])
    # print "-------carell train------- \n", carell_train, carell_train.shape

    baldwin_train_2, baldwin_val_2, baldwin_test_2 = vec_set(train_set_2["baldwin"], val_set_2["baldwin"], test_set_2["baldwin"])
    carell_train_2, carell_val_2, carell_test_2 = vec_set(train_set_2["carell"], val_set_2["carell"], test_set_2["carell"])

    training_x = get_x(baldwin_train, carell_train)
    validation_x = get_x(baldwin_val, carell_val)
    test_x = get_x(baldwin_test, carell_test)

    training_x_2 = get_x(baldwin_train_2, carell_train_2)

    #
    # print "------------------------training x2-----------------"
    # print training_x_2, training_x_2.shape

    training_y = get_y(baldwin_train, carell_train)
    validation_y = get_y(baldwin_val, carell_val)
    test_y = get_y(baldwin_test, carell_test)

    # print "-------baldwin train-------"
    # print baldwin_train
    # print baldwin_train.shape
    training_y_2 = get_y(baldwin_train_2, carell_train_2)


    theta_0 = np.zeros([1025, 1])

    theta = grad_descent(f, df, training_x.T, training_y, theta_0, 10E-7, iteration)

    # for training size 2
    theta_2 = grad_descent(f, df, training_x_2.T, training_y_2, theta_0, 10E-7, iteration)

    print "----------training---------"
    print training_x.shape
    train_percent = percentage(training_x.T, training_y, theta)
    val_percent = percentage(validation_x.T, validation_y, theta)
    test_percent = percentage(test_x.T, test_y, theta)

    print "training set performance: ", train_percent
    print "validation set performance: ", val_percent
    print "test set performance: ", test_percent

    print "cost function training= ", f(training_x.T, training_y, theta)
    print "cost function validation= ", f(validation_x.T, validation_y, theta)

    return theta, theta_2


def part4a():
    # t, t_2 = part3(80000)
    part_4_a = np.reshape(t[1:], [32, 32])
    imshow(part_4_a, cmap = "coolwarm")
    show()
    imsave('part_4_a_full.jpg', part_4_a, cmap="coolwarm")

    #for training size 2
    part_4_a_2 = np.reshape(t_2[1:], [32, 32])
    imshow(part_4_a_2, cmap = "coolwarm")
    show()
    imsave('part_4_a_2.jpg', part_4_a_2, cmap="coolwarm")


def part4b():
    t3, t4 = part3(10)
    part_4_b_1 = np.reshape(t3[1:], [32, 32])
    imshow(part_4_b_1, cmap = "coolwarm")
    show()
    imsave('part_4_b_1.jpg', part_4_b_1, cmap="coolwarm")



def part5():

    act = ['Lorraine Bracco', 'Peri Gilpin', 'Angie Harmon', 'Alec Baldwin', 'Bill Hader', 'Steve Carell']

    actors_test = ['Kristin Chenoweth', 'America Ferrera', 'Fran Drescher', 'Daniel Radcliffe', 'Gerard Butler', 'Michael Vartan']

    training_percent = []
    validation_percent = []
    test_percent_other = []

    sizes = [5, 10, 20, 30, 40, 50, 60, 70]
    # For different training size
    for t_size in sizes:
        train_set, val_set, test_set = get_set_gender(act, t_size)
        test_set_t = get_test_gender(actors_test, t_size)

        total_train_set = np.empty([0, 1024])
        total_valid_set = np.empty([0, 1024])
        total_test_other = np.empty([0, 1024])

        for i in range(len(act)):
            act_train, act_val, act_test = vec_set(train_set[act[i]], val_set[act[i]], [])
            t_test = get_img_vector(test_set_t[actors_test[i]])
            total_train_set = np.vstack((total_train_set, act_train))
            total_valid_set = np.vstack((total_valid_set, act_val))
            total_test_other = np.vstack((total_test_other, t_test))

        # y indicates if its a female or not. male: 1, female: 0
        act_train_y = get_y_gender(total_train_set)
        act_val_y = get_y_gender(total_valid_set)
        t_test_y = get_y_gender(total_test_other)

        theta = np.zeros([1025, 1])
        t = grad_descent(f, df, total_train_set.T, act_train_y, theta, 10E-7, 30000)

        training_percent.append(percentage(total_train_set.T, act_train_y, t))
        validation_percent.append(percentage(total_valid_set.T, act_val_y, t))
        test_percent_other.append(percentage(total_test_other.T, t_test_y, t))

    performance = np.concatenate((np.array([training_percent]), np.array([validation_percent])), axis=0)
    performance = np.concatenate((performance, np.array([test_percent_other])), axis=0)

    print "-------peformnce-------"
    print performance
    print performance.shape

    plt.plot(sizes, performance[0], color='r', marker='o', label="Training set")
    plt.plot(sizes, performance[1], color='b', marker='o', label="Validation set")
    plt.plot(sizes, performance[2], color='g', marker='o', label="Other's test set")

    plt.title("Performance on the training & validation sets vs training set size")
    plt.ylim([0,100])
    plt.xlabel("Training set size")
    plt.ylabel("Performance")
    plt.legend(loc='best')
    plt.savefig("part5.jpg")
    plt.show()


def part6d():

    act = ['Lorraine Bracco', 'Peri Gilpin', 'Angie Harmon', 'Alec Baldwin', 'Bill Hader', 'Steve Carell']

    train_set, val_set, test_set = get_set_gender(act, 50)

    np.random.seed(7)
    total_train_set = np.empty([0, 1024])
    total_valid_set = np.empty([0, 1024])
    total_test_set = np.empty([0, 1024])

    for i in range(len(act)):
        act_train, act_val, act_test = vec_set(train_set[act[i]], val_set[act[i]], test_set[act[i]])
        total_train_set = np.vstack((total_train_set, act_train))
        total_valid_set = np.vstack((total_valid_set, act_val))
        total_test_set = np.vstack((total_test_set, act_test))

    act_train_y = get_several_y(50, act)


    print "----------------total train set-------------------"
    print total_train_set
    print total_train_set.shape
    print "----------------total train set y-------------------"
    print act_train_y.shape

    theta = np.zeros([1025, 6])
    t = grad_descent_2(f, vectorized_gradient, total_train_set.T, act_train_y, theta, 10E-5, 100)

    for i in range(5):
        m = np.random.randint(0, 1025)
        n = np.random.randint(0, len(act)-1)
        finite_difference_compare(total_train_set, act_train_y, t, m, n)


def part7():
    act = ['Lorraine Bracco', 'Peri Gilpin', 'Angie Harmon', 'Alec Baldwin', 'Bill Hader', 'Steve Carell']

    train_set, val_set, test_set = get_set_gender(act, 65)

    total_train_set = np.empty([0, 1024])
    total_valid_set = np.empty([0, 1024])
    total_test_set = np.empty([0, 1024])

    for i in range(len(act)):
        act_train, act_val, act_test = vec_set(train_set[act[i]], val_set[act[i]], test_set[act[i]])
        total_train_set = np.vstack((total_train_set, act_train))
        total_valid_set = np.vstack((total_valid_set, act_val))
        total_test_set = np.vstack((total_test_set, act_test))

    act_train_y = get_several_y(65, act)
    act_val_y = get_several_y(10, act)
    act_test_y = get_several_y(10, act)

    theta_0 = np.zeros([1025, 6])
    theta = grad_descent_7(f, vectorized_gradient, total_train_set.T, act_train_y, theta_0, 10E-7)

    print "train set performance", percentage_2(total_train_set.T, act_train_y, theta)
    print "validation set performance", percentage_2(total_valid_set.T, act_val_y, theta)
    print "test set performance", percentage_2(total_test_set.T, act_test_y, theta)

    return theta.T


def part8():

    for i in range(6):
        part7_img = t[i][1:].reshape(32,32)
        imshow(part7_img, cmap="coolwarm")
        imsave("part7_"+str(i)+".jpg", part7_img, cmap="coolwarm")
        show()




# t, t_2 = part3(80000)
# part4a()
# part4b()
# part5()
# part6d()
part6d()
# part8()







