from pylab import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
import random
import time
from scipy.misc import *
import matplotlib.image as mpimg
import os
from scipy.ndimage import filters
import urllib

from rgb2gray import rgb2gray


def get_set(actors, train_size):
    training_sets = {}
    validation_sets = {}
    test_sets = {}

    for actor in actors:
        temp = []
        for image in os.listdir("cropped/"):
            if actor in image:
                temp.append(image)
        np.random.seed(7)
        np.random.shuffle(temp)
        training_sets[actor] = temp[20:20 + train_size]
        validation_sets[actor] = temp[10:20]
        test_sets[actor] = temp[0:10]
    return training_sets, validation_sets, test_sets


def get_set_gender(actors, train_size):
    training_sets = {}
    validation_sets = {}
    test_sets = {}

    for actor in actors:
        a = actor.split()[1].lower()
        temp = []
        for image in os.listdir("cropped/"):
            if a in image:
                temp.append(image)
        np.random.seed(7)
        np.random.shuffle(temp)
        training_sets[actor] = temp[10:10 + train_size]
        validation_sets[actor] = temp[0:10]
        # test_sets[actor] = temp[0:10]
    return training_sets, validation_sets, test_sets


def get_test_gender(actors, train_size):
    test_sets = {}

    for actor in actors:
        a = actor.split()[1].lower()
        temp = []
        for image in os.listdir("cropped/"):
            if a in image:
                temp.append(image)
        np.random.seed(7)
        np.random.shuffle(temp)
        # training_sets[actor] = temp[10:10 + train_size]
        # validation_sets[actor] = temp[0:10]
        test_sets[actor] = temp[0:10]
    return test_sets


def f(x, y, theta):
    x = vstack((ones((1, x.shape[1])), x))
    return sum ((y - dot(theta.T, x)) ** 2)


def df(x, y, theta):
    x = vstack((ones((1, x.shape[1])), x))
    return -2 * sum((y - dot(theta.T, x)) * x, 1)


def grad_descent(f, df, x, y, init_t, alpha, iteration):
    EPS = 1e-5
    prev_t = init_t - 10 * EPS
    t = init_t.copy()
    max_iter = iteration
    iter = 0
    while norm(t - prev_t) > EPS and iter < max_iter:
        prev_t = t.copy()
        t -= alpha*df(x, y, t).reshape(1025, 1)

        if iter % 500 == 0:
            print "Iter", iter
            print "x = (%.2f, %.2f, %.2f), f(x) = %.2f" % (t[0], t[1], t[2], f(x, y, t))
            print "Gradient: ", df(x, y, t), "\n"
        iter += 1
    return t


# input set is a set containing training set or valid set, or test set for a
# certain actor
def get_img_vector(input_set):
    l = np.zeros([len(input_set), 1024])

    i = 0
    for f_name in os.listdir("cropped/"):
        if f_name in input_set:

            path = "cropped/" + f_name
            im = imread(path)
            im = im.flatten()
            l[i] = reshape(np.array(im), [1, 1024])
            print "l[i]", l[i]
            i += 1
    l /= 255
    return l


def vec_set(training, validation, test):
    tr_vec = get_img_vector(training)
    print "tr_vec: ", tr_vec
    va_vec = get_img_vector(validation)
    te_vec = get_img_vector(test)

    return tr_vec, va_vec, te_vec


def percentage(x, y, theta, size):
    real = y[0]
    x = vstack((ones((1, x.shape[1])), x))
    hypo = dot(theta.T, x)
    num_correct = 0

    for i in range(size):
        if hypo[:, i] > 0.5:
            if real[i] == 1:
                num_correct += 1
        else:
            if real[i] == 0:
                num_correct += 1
    percent = num_correct/float(size)
    return percent * 100


def get_y(set_a, set_b):
    print "----------------------"
    result = []
    print len(set_a), len(set_b)
    y = np.zeros((len(set_a) + len(set_b)))
    for i in range(len(set_a), len(set_b) + len(set_a)):
        y[i] = 1

    result.append(y)
    return array(result)


def get_y_gender(sets):
    #
    result = []
    length = len(sets)
    y = np.zeros(length)
    for i in range(length/2, length):
        y[i] = 1

    result.append(y)
    return array(result)


def get_x(set_a, set_b):
    result = np.vstack((set_a, set_b))
    return result


def part5():

    act = ['Lorraine Bracco', 'Peri Gilpin', 'Angie Harmon', 'Alec Baldwin', 'Bill Hader', 'Steve Carell']

    actors_test = ['Kristin Chenoweth', 'America Ferrera', 'Fran Drescher', 'Daniel Radcliffe', 'Gerard Butler', 'Michael Vartan']

    training_percent = []
    validation_percent = []
    test_percent_other = []

    sizes = [5, 10, 20, 30, 40, 50, 60, 70]
    # For different training size
    for t_size in sizes:
        train_set, val_set, test_set = get_set_gender(act, t_size)
        test_set_t = get_test_gender(actors_test, t_size)

        total_train_set = np.empty([0, 1024])
        total_valid_set = np.empty([0, 1024])
        total_test_other = np.empty([0, 1024])

        for i in range(len(act)):
            act_train, act_val, act_test = vec_set(train_set[act[i]], val_set[act[i]], [])
            t_test = get_img_vector(test_set_t[actors_test[i]])
            total_train_set = np.vstack((total_train_set, act_train))
            total_valid_set = np.vstack((total_valid_set, act_val))
            total_test_other = np.vstack((total_test_other, t_test))

        # y indicates if its a female or not. male: 1, female: 0
        act_train_y = get_y_gender(total_train_set)
        act_val_y = get_y_gender(total_valid_set)
        t_test_y = get_y_gender(total_test_other)

        theta = 0.5 * np.zeros([1025, 1])
        t = grad_descent(f, df, total_train_set.T, act_train_y, theta, 5E-7, 1000)

        training_percent.append(percentage(total_train_set.T, act_train_y, t, t_size * 6))
        validation_percent.append(percentage(total_valid_set.T, act_val_y, t, 10 * 6))
        test_percent_other.append(percentage(total_test_other.T, t_test_y, t, 10 * 6))

    performance = np.concatenate((np.array([training_percent]), np.array([validation_percent])), axis=0)
    performance = np.concatenate((performance, np.array([test_percent_other])), axis=0)

    print "-------peformnce-------"
    print performance
    print performance.shape

    plt.plot(sizes, performance[0], color='r', linewidth=1, label="Training set")
    plt.plot(sizes, performance[1], color='b', linewidth=1, marker='o', label="Validation set")
    plt.plot(sizes, performance[2], color='g', linewidth=1, marker='o', label="Other's test set")

    plt.title("Performance on the training & validation sets vs training set size")
    plt.ylim([0,100])
    plt.xlabel("Training set size")
    plt.ylabel("Performance")
    plt.savefig("part5.jpg")
    plt.show()


part5()
