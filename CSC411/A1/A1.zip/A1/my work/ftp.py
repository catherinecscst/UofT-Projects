from pylab import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
import random
import time
from scipy.misc import imread
from scipy.misc import imresize
import matplotlib.image as mpimg
import os
from scipy.ndimage import filters
import urllib


def get_set(actors):
    training_sets = {}
    validation_sets = {}
    test_sets = {}

    for actor in actors:
        temp = []
        for image in os.listdir("stellacropped/"):
            if actor in image:
                temp.append(image)
        np.random.shuffle(temp)
        training_sets[actor] = temp[20:90]
        validation_sets[actor] = temp[10:20]
        test_sets[actor] = temp[0:10]
    return training_sets, validation_sets, test_sets


def f(x, y, theta):
    x = vstack((ones((1, x.shape[1])), x))
    return sum ((y - dot(theta.T, x)) ** 2)


def df(x, y, theta):
    x = vstack((ones((1, x.shape[1])), x))
    return -2 * sum((y - dot(theta.T, x)) * x, 1)


def grad_descent(f, df, x, y, init_t, alpha):
    EPS = 1e-5
    prev_t = init_t - 10 * EPS
    t = init_t.copy()
    max_iter = 3000
    iter = 0
    while norm(t - prev_t) > EPS and iter < max_iter:
        prev_t = t.copy()
        t -= alpha*df(x, y, t).reshape(1025, 1)

        if iter % 500 == 0:
            print "Iter", iter
            print "x = (%.2f, %.2f, %.2f), f(x) = %.2f" % (t[0], t[1], t[2], f(x, y, t))
            print "Gradient: ", df(x, y, t), "\n"
        iter += 1
    return t


# input set is a set containing training set or valid set, or test set for a
# certain actor
def get_img_vector(input_set):
    l = np.zeros([len(input_set), 1024])

    i = 0
    for f_name in os.listdir("stellacropped/"):
        if f_name in input_set:

            path = "stellacroppeds/" + f_name
            im = imread(path)
            im = im.flatten()
            l[i] = reshape(np.array(im), [1, 1024])
            print "l[i]", l[i]
            i += 1
    l /= 255
    return l


def vec_set(training, validation, test):
    tr_vec = get_img_vector(training)
    print "tr_vec: ", tr_vec
    va_vec = get_img_vector(validation)
    te_vec = get_img_vector(test)

    return tr_vec, va_vec, te_vec

def linear_classifier(training_x, training_y, dim_row, dim_col, alpha):
    # x = hstack((ones([dim_col, 1]), training_set))
    theta = np.random.rand(dim_row + 1, dim_col) * (1E-9)
    t = grad_descent(f, df, training_x.T, training_y, theta, alpha)
    return t

def performance(x, y, theta, size):
    correct_y = y[0]
    x = vstack((ones((1, x.shape[1])), x))
    h = dot(theta.T, x)
    predicted_y = []

    for i in range(len(correct_y)):
        if h[:, i] > 0.5:
            predicted_y.append(1)
        else:
            predicted_y.append(0)

    num_correct = 0
    for c, p in zip(correct_y, predicted_y):
        if p == c:
            num_correct += 1
    return num_correct / float(size)


def get_y(set_a, set_b):
    print "----------------------"
    result = []
    print len(set_a), len(set_b)
    y = np.zeros((len(set_a) + len(set_b)))
    for i in range(len(set_a), len(set_b) + len(set_a)):
        y[i] = 1

    result.append(y)
    return array(result)


def part3():
    actors = ["baldwin", "carell"]
    train_set, val_set, test_set = get_set(actors)
    print train_set["baldwin"]
    print train_set["carell"]

    baldwin_train, baldwin_val, baldwin_test = vec_set(train_set["baldwin"], val_set["baldwin"], test_set["baldwin"])
    print baldwin_train
    carell_train, carell_val, carell_test = vec_set(train_set["carell"], val_set["carell"], test_set["carell"])
    print "carell train \n", carell_train

    training_x = np.concatenate((baldwin_train, carell_train), axis=0)
    validation_x = np.concatenate((baldwin_val, carell_val), axis=0)
    test_x = np.concatenate((baldwin_test, carell_test), axis=0)

    training_y = get_y(baldwin_train, carell_train)
    validation_y = get_y(baldwin_val, carell_val)
    test_y = get_y(baldwin_test, carell_test)

    # print "-------training y-------"
    # print training_y
    # print training_y.shape
    # print "-------validation y-------"
    # print validation_y
    # print validation_y.shape
    # print "-------test y-------"
    # print test_y
    # print test_y.shape

    t = linear_classifier(training_x, training_y, 1024, 1, 5E-7)
    print("theta: ", t)
    imshow(reshape(t[1:], [32, 32]), cmap=cm.coolwarm)
    show()
    imsave('part3_theta_training' + str(70) + '.jpg', reshape(t[1:], [32, 32]), cmap=cm.coolwarm)

    train_p = performance(training_x.T, training_y, t, 140)
    val_p = performance(validation_x.T, validation_y, t, 20)
    test_p = performance(test_x.T, test_y, t, 20)
    print training_x.T[0]
    print training_y
    print "f_training= ", f(training_x.T, training_y, t)
    print "f_validation= ", f(validation_x.T, validation_y, t)
    print("TRAIN PERFORMANCE: %f", train_p * 100)
    print("VALIDATION PERFORMANCE: %f", val_p * 100)
    print("TEST PERFORMANCE: %f", test_p * 100)


part3()
