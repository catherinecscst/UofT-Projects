from pylab import *
import numpy as np
from textwrap import wrap
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
import random
import time
from scipy.misc import imread
from scipy.misc import imresize
import matplotlib.image as mpimg
import os
from scipy.ndimage import filters
import urllib

#from script import *

# ============== PART 1 ======================
def part1():
    # start processing
    # getting_uncropped()
    # process_images()
    # already ran in script.py (not imported)
    pass

# ============== PART 2 ======================
def part2(name):
    """
    Input has to be the last name of an actor/actress in lower case.
    Examples: 'bracco', 'gilpin', 'garmon', 'baldwin', 'hader', 'carell' ...
    """
    # make sure have three non-overlapping set for each actor/actress
    options = []
    for imgs in os.listdir("cropped/"):
        if name in imgs:
            #print imgs
            options.append(imgs)
    # Shuffle
    np.random.seed(10)
    np.random.shuffle(options)
    # 70 training set
    training_set = options[0:70]
    # 10 validation set
    validation_set = options[70:80]
    # 10 test set
    test_set = options[80:90]

    return training_set, validation_set, test_set

# ======= HELPERS FOR PART 3 ======================
def f(x, y, theta):
    x = vstack((ones((1, x.shape[1])), x))
    return sum ((y - dot(theta.T, x)) ** 2)


def df(x, y, theta):
    x = vstack((ones((1, x.shape[1])), x))
    return -2 * sum((y - dot(theta.T, x)) * x, 1)


def grad_descent(f, df, x, y, init_t, alpha):
    EPS = 1e-5
    prev_t = init_t - 10 * EPS
    t = init_t.copy()

    max_iter = 30000
    iter = 0
    while norm(t - prev_t) > EPS and iter < max_iter:
        prev_t = t.copy()
        t -= alpha*df(x, y, t).reshape(1025, 1)

        if iter % 500 == 0:
            print "Iter: ", iter
            print "x = (%.2f, %.2f, %.2f), f(x) = %.2f" % (t[0], t[1], t[2], f(x, y, t))
            print "Gradient: ", df(x, y, t), "\n"
        iter += 1
    return t


def get_imgs(input, set_size):

    marx = np.zeros((set_size, 1024))
    i = 0
    for imgs in os.listdir("cropped/"):
        if imgs in input:
            img_path = "cropped/" + imgs
            im = imread(img_path).flatten()
            marx[i] = reshape(np.array(im), [1, 1024])
            i += 1
    return marx / 255


def imgs_sets(b_tr, b_v, bt, c_tr, c_v, ct):

    training_set = np.append(b_tr, c_tr, axis=0)
    validation_set = np.append(b_v, c_v, axis=0)
    test_set = np.append(bt, ct, axis=0)

    return training_set, validation_set, test_set

def imgs_sets_y(size):

    result = []
    y = np.zeros((size*2))
    for i in range(size, size*2):
        y[i] = 1
    result.append(y)
    return array(result)

def percentage_cal(a, b, s):
    counter = 0
    for ai, bi in zip(a, b):
        if bi == ai:
            counter += 1
    return (counter / float(s)) * 100

# ============== PART 3 ======================
def part3():
    training_set, validation_set, test_set = {}, {}, {}
    # actors = ["baldwin", "carell"]
    # ==Part2(name)==
    training_set["baldwin"], validation_set["baldwin"], test_set["baldwin"] = part2("baldwin")
    training_set["carell"], validation_set["carell"], test_set["carell"] = part2("carell")

    #get_imgs(input, set_size)
    b_tr, b_v, bt = get_imgs(training_set["baldwin"], 70), get_imgs(validation_set["baldwin"], 10), get_imgs(test_set["baldwin"], 10)
    c_tr, c_v, ct = get_imgs(training_set["carell"], 70), get_imgs(validation_set["carell"], 10), get_imgs(test_set["carell"], 10)

    training_smg, validation_smg, test_smg = imgs_sets(b_tr, b_v, bt, c_tr, c_v, ct)

    training_y, validation_y, test_y = imgs_sets_y(70), imgs_sets_y(10), imgs_sets_y(10)

    theta = np.random.rand(1025, 1) * (1E-5)
    t = grad_descent(f, df, training_smg.T, training_y, theta, 5E-6)

    # this is for part 4 ===
    imsave('part3.jpg', reshape(t[1:], [32, 32]), cmap=cm.coolwarm)

    print "values of the cost function on the training: ", f(training_smg.T, training_y, t)
    print "values of the cost function on the validation: ", f(validation_smg.T, validation_y, t)

    training_correct = training_y[0]
    h = dot(t.T, vstack((ones((1, training_smg.T.shape[1])), training_smg.T)))
    training_prediction = []
    train_len = len(training_correct)

    for i in range(train_len):
        if h[:, i] < 0.5:
            training_prediction.append(0)
        else:
            training_prediction.append(1)
    print("performance  on training:", percentage_cal(training_correct, training_prediction, 140))

    validation_correct = validation_y[0]
    h = dot(t.T, vstack((ones((1, validation_smg.T.shape[1])), validation_smg.T)))
    validation_prediction = []
    valid_len = len(validation_correct)

    for i in range(valid_len):
        if h[:, i] < 0.5:
            validation_prediction.append(0)
        else:
            validation_prediction.append(1)
    print("performance on validation:", percentage_cal(validation_correct, validation_prediction, 20))


#part3()

# ============== PART 4 ======================
def part4():
    # used part 3 code (modified it and got the results)
    # full data set was 132 images
    # results see the report
    pass

# ================== PART 5  HELPERS =================

def part2_lst(names, tr_size):
    training_set, validation_set, test_set = {}, {}, {}
    for a in names:
        options = []
        for imgs in os.listdir("cropped/"):
            if a in imgs:
                options.append(imgs)
        np.random.seed(5)
        np.random.shuffle(options)

        training_set[a] = options[0:tr_size]
        validation_set[a] = options[tr_size:tr_size + 10]

        #np.random.seed(6)
        #np.random.shuffle(options)
        test_set[a] = options[0:10]

    return training_set, validation_set, test_set
def imgs_sets_y_p5(size):

    sy = []
    y = np.zeros(size)
    for i in range(size / 2, size):
        y[i] = 1
    sy.append(y)
    return array(sy)

# ============== PART 5 ======================
def part5():

    training_act_performance = []
    validation_act_performance = []
    test_others_performance = []

    act_names = ['bracco', 'gilpin', 'harmon', 'baldwin', 'hader', 'carell']
    others_names = ['butler', 'vartan', 'radcliffe', 'drescher', 'ferrera', 'chenoweth']
    size_range = range(10, 70, 10)
    for size in size_range:
        # only need training set and validation set for act_name
        # and test set for others_names
        training_set, validation_set, c = part2_lst(act_names, size)
        a, b, test_set = part2_lst(others_names, size)
        training_stack, validation_stack, test_stack = np.empty((0, 1024)), np.empty((0, 1024)), np.empty((0, 1024))

        # get imgs for 6 people
        for i in range(6):
            training_img = get_imgs(training_set[act_names[i]], size)
            validation_img = get_imgs(validation_set[act_names[i]], 10)
            test_img = get_imgs(test_set[others_names[i]], 10)
            training_stack = np.concatenate((training_stack, training_img))
            validation_stack = np.concatenate((validation_stack, validation_img))
            test_stack = np.concatenate((test_stack, test_img))

        tr_len, v_len, t_len = len(training_stack), len(validation_stack), len(test_stack)
        training_ylabel, validation_ylabel, test_ylabel = imgs_sets_y_p5(tr_len), imgs_sets_y_p5(v_len), imgs_sets_y_p5(t_len)


        theta = np.random.rand(1025, 1) * (1E-5)
        t = grad_descent(f, df, training_stack.T, training_ylabel, theta, 10E-7)

        training_size = size * 6
        valntest_szie = 60
        # calculating the performance on all training sets
        training_se, validation_se, test_se = training_stack.T, validation_stack.T, test_stack.T
        training_correct, validation_correct, test_correct = training_ylabel[0], validation_ylabel[0], test_ylabel[0]
        h_training = dot(t.T, vstack((ones((1, training_se.shape[1])), training_se)))
        h_validation = dot(t.T, vstack((ones((1, validation_se.shape[1])), validation_se)))
        h_test = dot(t.T, vstack((ones((1, test_se.shape[1])), test_se)))
        training_counter, validation_counter, test_counter= 0, 0, 0

        for i in range(training_size):
            if (((h_training[:, i] < 0.5) and (training_correct[i] == 0)) or
                    ((h_training[:, i] > 0.5) and (training_correct[i] == 1))):
                training_counter += 1
        for i in range(valntest_szie):
            if (((h_validation[:, i] < 0.5) and (validation_correct[i] == 0)) or
                    ((h_validation[:, i] > 0.5) and (validation_correct[i] == 1))):
                validation_counter += 1
            if (((h_test[:, i] < 0.5) and (test_correct[i] == 0)) or
                    ((h_test[:, i] > 0.5) and (test_correct[i] == 1))):
                test_counter += 1

        training_act_performance.append ((training_counter / float(training_size)) * 100)
        validation_act_performance.append ((validation_counter / float(valntest_szie)) * 100)
        test_others_performance.append ((test_counter / float(valntest_szie)) * 100)


    act_performances = vstack((np.array(training_act_performance), np.array(validation_act_performance)))
    all_performances = vstack((act_performances, np.array(test_others_performance)))

    print "plot drawing"
    title = "The performance of the classifiers on the training and validation sets VS The size of the training set"
    plt.title('\n'.join(wrap(title, 60)))
    plt.xlabel("Size of the Training set")
    plt.ylabel("Performance in percentage")
    plt.ylim([0,100])
    plt.plot(size_range, all_performances[0], color="tab:red", marker='.', label="training sets")
    plt.plot(size_range, all_performances[1], color="tab:purple", marker='.', label="validation sets")
    plt.plot(size_range, all_performances[2], color="tab:blue", marker='.', label="test sets")
    plt.legend(loc='best')
    plt.savefig("part5plot.jpg")

#part5()

# ============== PART 6 ======================

def f_6a(x, y, theta):
    x = vstack((np.ones((1, x.shape[1])), x))
    return sum((y - dot(transpose(x), theta.T)) ** 2)

# according to 6(a)
def df_6a(x, y, theta):
    x = vstack((np.ones((1, x.shape[1])), x))
    return 2 * dot(x, (dot(theta.T,x) - y.T).T)

# 6d()
def grad_descent_6d(f, df, x, y, init_t, alpha):
    EPS = 1e-5
    prev_t = init_t - 10 * EPS
    t = init_t.copy()

    max_iter = 10000
    iter = 0
    while norm(t - prev_t) > EPS and iter < max_iter:
        prev_t = t.copy()
        t -= alpha*df_6a(x, y, t)
        if iter % 500 == 0:
            print "Iter: ", iter
        iter += 1
    return t


def part6():
    training_size = 50
    act_names = ['bracco', 'gilpin', 'harmon', 'baldwin', 'hader', 'carell']
    training_set, validation_set, test_set = part2_lst(act_names, training_size)

    training_stack = np.empty((0, 1024))
    for i in range(6):
        act_train = get_imgs(training_set[act_names[i]], training_size)
        training_stack = np.vstack((training_stack, act_train))

    m_training = np.zeros((training_size * 6, 6))
    training_counter, training_idx, = 0, 0
    for i in range(training_size * 6):
        training_cp = 0
        for j in range(6):
            if j == 6:
                loop_index = 0
            else :
                loop_index = j
            if loop_index == training_idx and training_cp == 0:
                m_training[i][j], training_cp = 1, 1
                training_counter += 1
                if training_counter == training_size:
                    training_idx += 1
                    training_counter = 0
    training_ylabel = m_training

    theta = np.zeros((1025, 6))
    training_se, label_se = training_stack[1], training_ylabel[1]
    t = grad_descent_6d(f, df_6a, training_stack.T, training_ylabel, theta, 10E-6)

    # along 5 coordinates
    for i in range(5):
        h_value = 1e-7
        theta = t.copy()
        mtx_l, mtx_r = np.random.randint(0, 1025), np.random.randint(0, 5)
        theta[mtx_l, mtx_r] = t[mtx_l, mtx_r] + h_value
        x = training_se.T.reshape(1024, 1)
        y = label_se.reshape(1,6)
        print "=== [", mtx_l, ",", mtx_r, "] ==="
        print "finite difference:", (f_6a(x, y, (theta).T) - f_6a(x, y, t.T))/float(h_value)
        print "gradient output:", df_6a(x, y, t)[i, j]


# ============== PART 7 ======================

def performance_on_part7(x, y, size, theta):
    h_sets = dot(vstack((ones((1, x.shape[1])), x)).T, theta)
    correct_perform = 0.
    for i in range(len(y)):
        if h_sets[i].argmax() == y[i].argmax():
            correct_perform += 1
    counter = correct_perform / x.shape[1]
    return counter * 100


def part7():
    training_size, validation_size = 70, 10
    act_names = ['bracco', 'gilpin', 'harmon', 'baldwin', 'hader', 'carell']
    training_set, validation_set, test_set = part2_lst(act_names, training_size)
    training_stack, validation_stack = np.empty((0, 1024)), np.empty((0, 1024))

    for i in range(6):
        training_img = get_imgs(training_set[act_names[i]], training_size)
        validation_img = get_imgs(validation_set[act_names[i]], validation_size)
        training_stack = np.concatenate((training_stack, training_img))
        validation_stack = np.concatenate((validation_stack, validation_img))
    m_training, m_validation= np.zeros((training_size * 6, 6)), np.zeros((validation_size * 6, 6))
    training_counter, validation_counter, training_idx, validation_idx = 0, 0, 0, 0
    for i in range(training_size * 6):
        training_cp, validation_cp = 0, 0
        for j in range(6):
            if j == 6:
                loop_index = 0
            else :
                loop_index = j
            if loop_index == training_idx and training_cp == 0:
                m_training[i][j], training_cp = 1, 1
                training_counter += 1
                if training_counter == training_size:
                    training_idx += 1
                    training_counter = 0
            if loop_index == validation_idx and validation_cp == 0:
                m_validation[i][j], validation_cp = 1, 1
                validation_counter += 1
                if validation_counter == validation_size:
                    validation_idx += 1
                    validation_counter = 0
    training_ylabel, validation_ylabel = m_training, m_validation


    theta = np.random.rand(1025, 6) * (1E-5)
    t = grad_descent_6d(f, df_6a, training_stack.T, training_ylabel, theta, 10E-7)

    size_training_label, size_validation_label = len(training_ylabel), len(validation_ylabel)
    print "performance  on training:", performance_on_part7(training_stack.T, training_ylabel, size_training_label, t)
    print "performance on validation:", performance_on_part7(validation_stack.T, validation_ylabel, size_validation_label, t)

    return t

# ============== PART 8 ======================
def part8():
    theta = part7()
    for i in range(6):
        imsave('part8_' + str(i) + '.jpg', theta.T[i][1:].reshape(32,32), cmap=cm.coolwarm)

#part8()
