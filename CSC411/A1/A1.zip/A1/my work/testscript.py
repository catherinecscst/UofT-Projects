from pylab import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
import random
import time
from scipy.misc import imread
from scipy.misc import imresize
import matplotlib.image as mpimg
import os
from scipy.ndimage import filters
import urllib


act = list(set([a.split("\t")[0] for a in open("facescrub_actresses.txt").readlines()]))


def timeout(func, args=(), kwargs={}, timeout_duration=1, default=None):
    '''From:
    http://code.activestate.com/recipes/473878-timeout-function-using-threading/'''
    import threading
    class InterruptableThread(threading.Thread):
        def __init__(self):
            threading.Thread.__init__(self)
            self.result = None

        def run(self):
            try:
                self.result = func(*args, **kwargs)
            except:
                self.result = default

    it = InterruptableThread()
    it.start()
    it.join(timeout_duration)
    if it.isAlive():
        return False
    else:
        return it.result

def rgb2gray(rgb):
    '''Return the grayscale version of the RGB image rgb as a 2D numpy array
    whose range is 0..1
    Arguments:
    rgb -- an RGB image, represented as a numpy array of size n x m x 3. The
    range of the values is 0..255
    '''

    r, g, b = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2]
    gray = 0.2989 * r + 0.5870 * g + 0.1140 * b

    return gray/255.

###provided code above

#Note: you need to create the uncropped folder first in order
#for this to work

testfile = urllib.URLopener()

def getting_uncropped(src_path, dest_path):
    for a in act:
        name = a.split()[1].lower()
        i = 0
        for line in open(src_path):
            if a in line:
                coord = line.split()[5].split(",")
                coords = tuple(map(int, coord))
                #                      = added coord =
                filename = name+str(i)+'.'+str(coords)+'.'+line.split()[4].split('.')[-1]
                #filename = name+str(i)+'.'+line.split()[4].split('.')[-1]
                try:
                    testfile.retrieve(line.split()[4], dest_path+filename)
                except Exception as e:
                    print(filename, str(e))
                #timeout(testfile.retrieve, (line.split()[4], dest_file+filename), {}, 30)
                if not os.path.isfile(dest_path+filename):
                    continue

                print filename
                i += 1

def process_images(src_path, dest_path):
    imglst = []
    for file in os.listdir(src_path):
        try:
            readimg = imread(os.path.join(src_path, file))
            coords_lst = map(int, file.split(".")[1][1:-1].split(","))
            #[y1:y2, x1:x2]
            cropped = readimg[coords_lst[1]:coords_lst[3], coords_lst[0]:coords_lst[2]]
            resized = imresize(cropped, [32, 32])
            grayscaled = rgb2gray(resized)
            if grayscaled is not None:
                imglst.append(grayscaled)
                filename = file.split(".")[0]+".jpg"
                cmap = cm.gray
                imsave(dest_path+filename, grayscaled, cmap = cm.gray)
        except Exception as e:
            print(file, str(e))


#start processing

##male subset
#getting_uncropped("facescrub_actors.txt", "uncropped_actors/")
#process_images("uncropped_actors/", "processed_actors/")


#female subset
getting_uncropped("facescrub_actresses.txt", "uncropped_actresses/")
process_images("uncropped_actresses/", "processed_actresses/")
