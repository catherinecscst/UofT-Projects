#include <stdio.h>
#include <assert.h>
#include <unistd.h>
#include <getopt.h>
#include <stdlib.h>
#include "pagetable.h"
#include "sim.h" //extern char *tracefile;

extern int debug;

extern struct frame *coremap;

extern int ref_count;

FILE *f;

int idx;
int count; // count for the lines in tracefile
addr_t *tr_vaddress;

/* Page to evict is chosen using the optimal (aka MIN) algorithm. 
 * Returns the page frame number (which is also the index in the coremap)
 * for the page that is to be evicted.
 */
int opt_evict() {
    int max_next_pos;
    int max_pfn;
    int next_pos;
    int condition;
    int i, j;

  	for (i = 0; i < memsize; i++) {
   		  addr_t cur_addr = coremap[i].virtual_address;
   	    condition = 0;
  		  next_pos = -1;
        j = ref_count + 1;
    	
	    while(j < count && condition == 0){
		      if((int)tr_vaddress[j] == (int)cur_addr){
		          next_pos = j - ref_count;
		          condition = -1;
		      }
		      j++;
	    }
	    if (next_pos == -1) {
          return i;
	    } else {
	      	if (i == 0 || next_pos > max_next_pos) {
	        	  max_next_pos = next_pos;
	        	  max_pfn = i;
      		}
    	}
  	}
  	return max_pfn;
}

/* This function is called on each access to a page to update any information
 * needed by the opt algorithm.
 * Input: The page table entry for the page that is being accessed.
 */
void opt_ref(pgtbl_entry_t *p) {
}

/* Initializes any data structures needed for this
 * replacement algorithm.
 */
void opt_init() {
  	int ln; // indicate the end of line in tracefile
  	count = 0; // count the lines
  	idx = 0;

  	char line[MAXLINE];
  	addr_t vaddress;

  	f = fopen(tracefile, "r");

  	if (f == NULL) {
   		  perror("fopen");
    	  exit(1);
  	}
    while ((ln = fgetc(f)) != EOF) {
      if (ln == '\n') {
	      	count++;
	      }
    }
    //set pointer back to the beginning of the file
  	fseek(f, 0, SEEK_SET);

  	tr_vaddress = malloc(sizeof(addr_t) * count);
  	int i;
    // read each line in tracefile
    while (fgets(line, MAXLINE, f) != NULL) {
        if(line[0] != '=') {
	      	  sscanf(line, "%*c %lx", &vaddress);
	      	  tr_vaddress[i] = (addr_t)vaddress;
	      	  i++;    
        }
	  }
  	fclose(f);
}