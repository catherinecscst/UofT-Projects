#include <stdio.h>
#include <assert.h>
#include <unistd.h>
#include <getopt.h>
#include <stdlib.h>
#include "pagetable.h"


extern int memsize;

extern int debug;

extern struct frame *coremap;

int ref;
int ref_num;

/* Page to evict is chosen using the accurate LRU algorithm.
 * Returns the page frame number (which is also the index in the coremap)
 * for the page that is to be evicted.
 */

int lru_evict() {
	int min_ref;
	int i = 0;
	int frame_number;
	// find the minimum ref bit page
	while (i < memsize) {
		ref_num = coremap[i].ref_bit;
		if (ref_num < min_ref || i == 0) {
			min_ref = ref_num;
			frame_number = i;
		}
		i++;
	}

	
	return frame_number;
}

/* This function is called on each access to a page to update any information
 * needed by the lru algorithm.
 * Input: The page table entry for the page that is being accessed.
 */
void lru_ref(pgtbl_entry_t *p) {
	ref++;
	int index = p->frame >> PAGE_SHIFT;
	coremap[index].ref_bit = ref;

	return;
}


/* Initialize any data structures needed for this 
 * replacement algorithm 
 */
void lru_init() {
	ref = 0;
}
