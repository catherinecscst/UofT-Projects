[Describe your issue]

#### Check all that apply (change to `[x]`)
- [ ] Windows
- [ ] Mac OS X
- [ ] Linux

See <https://libigl.github.io/CONTRIBUTING/#bugreport> for more tips.
