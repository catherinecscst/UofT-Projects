system('python tcpviewer_single.py&');

pause(0.1) % Wait a bit for the viewer to start