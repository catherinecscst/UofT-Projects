#### Describe your issue

...

#### Check all that apply (change to `[x]`)
- [ ] Windows
- [ ] Mac OS X
- [ ] Linux
- [ ] I have tried the `dev` branch and the problem persists

See https://libigl.github.io/CONTRIBUTING/#bugreport for more tips.
